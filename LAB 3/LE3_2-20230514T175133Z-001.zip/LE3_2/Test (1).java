class Test implements Testable{
    public void display(){
        System.out.println("test hai");
    }
}