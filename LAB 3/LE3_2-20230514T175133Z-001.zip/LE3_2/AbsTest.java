abstract class AbsTest implements Testable{
    public void display(){
        System.out.println("abstest hai");
    }
}