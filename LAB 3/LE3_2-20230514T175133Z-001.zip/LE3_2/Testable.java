interface Testable {
    void display();
}