abstract class Ducks{
 void swim()
 {
 System.out.println("can swim");
 }
 abstract void fly();
 abstract void speak();
}