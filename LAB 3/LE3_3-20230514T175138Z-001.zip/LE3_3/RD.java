class RD extends Ducks{
 void fly()
 {
 System.out.println("RD cant fly");
 }
 void speak()
 {
 System.out.println("RD squeaks");
 }
}