class WD extends Ducks{
 void fly()
 {
 System.out.println("WD cant fly");
 }
 void speak()
 {
 System.out.println("WD mute");
 }
}