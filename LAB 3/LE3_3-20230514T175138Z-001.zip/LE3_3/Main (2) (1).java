public class Main
{
public static void main(String[] args) 
{
RD R=new RD();
R.fly();
R.speak();
R.swim();
LD L=new LD();
L.fly();
L.speak();
L.swim();
RHD RH=new RHD();
RH.fly();
RH.speak();
RH.swim();
WD W=new WD();
W.fly();
W.speak();
W.swim();
}}