public class Main{
    public static void main(String args[]){
        Mother m= new Mother();
        Mother m1= new Mother();
        m1.show();
        m.show();
        Child ch= new Child();
        ch.show();
    }
}