public class Mother{
    public static void show(){
    System.out.println("Hello World");
}
}