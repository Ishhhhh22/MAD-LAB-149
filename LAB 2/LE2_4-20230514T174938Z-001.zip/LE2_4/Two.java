class Two extends One{
    
}