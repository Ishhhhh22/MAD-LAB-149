public class One{
    public One(int x){
        
    };
}